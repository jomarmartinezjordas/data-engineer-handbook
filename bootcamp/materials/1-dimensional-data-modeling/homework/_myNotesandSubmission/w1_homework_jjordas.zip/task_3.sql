CREATE TABLE actors_history_scd (
    actorid TEXT,
    actor TEXT,
    quality_class TEXT,
    is_active BOOLEAN,
    start_date INTEGER,
    end_date INTEGER
);