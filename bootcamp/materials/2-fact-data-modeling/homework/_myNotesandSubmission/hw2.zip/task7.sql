create table host_activity_reduced (
    host text, 
    month date, 
    hit_array integer[], 
    unique_visitors integer[], 
    primary key (month, host) 
);